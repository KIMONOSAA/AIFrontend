// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as chartController from './chartController';
export default {
  chartController,
};
