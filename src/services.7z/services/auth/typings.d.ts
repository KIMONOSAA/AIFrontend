declare namespace API {
  type AuthentianResponse = {
    accessToken?: string;
    refershToken?: string;
  };

  type BaseResponseAuthentianResponse = {
    code?: number;
    data?: AuthentianResponse;
    message?: string;
  };

  type BaseResponseBoolean = {
    code?: number;
    data?: boolean;
    message?: string;
  };

  type BaseResponseInteger = {
    code?: number;
    data?: number;
    message?: string;
  };

  type BaseResponseLoginUserVO = {
    code?: number;
    data?: LoginUserVO;
    message?: string;
  };

  type BaseResponseLong = {
    code?: number;
    data?: number;
    message?: string;
  };

  type BaseResponsePageUser = {
    code?: number;
    data?: PageUser;
    message?: string;
  };

  type BaseResponsePageUserVO = {
    code?: number;
    data?: PageUserVO;
    message?: string;
  };

  type BaseResponseString = {
    code?: number;
    data?: string;
    message?: string;
  };

  type BaseResponseUser = {
    code?: number;
    data?: User;
    message?: string;
  };

  type BaseResponseUserVO = {
    code?: number;
    data?: UserVO;
    message?: string;
  };

  type DeleteRequest = {
    id?: number;
  };

  type findAllValidTokenByUserParams = {
    id: number;
  };

  type findByEmailParams = {
    username: string;
  };

  type findByTokenParams = {
    jwt: string;
  };

  type getSaveUserTokenParams = {
    jwtToken: string;
  };

  type getUserByIdParams = {
    id: number;
  };

  type getUserVOByIdParams = {
    id: number;
  };

  type insertUserParams = {
    user: User;
  };

  type LoginUserVO = {
    id?: number;
    userAvatar?: string;
    userAccount?: string;
    createTime?: string;
    updateTime?: string;
  };

  type OrderItem = {
    column?: string;
    asc?: boolean;
  };

  type PageUser = {
    records?: User[];
    total?: number;
    size?: number;
    current?: number;
    orders?: OrderItem[];
    optimizeCountSql?: PageUser;
    searchCount?: PageUser;
    optimizeJoinOfCountSql?: boolean;
    maxLimit?: number;
    countId?: string;
    pages?: number;
  };

  type PageUserVO = {
    records?: UserVO[];
    total?: number;
    size?: number;
    current?: number;
    orders?: OrderItem[];
    optimizeCountSql?: PageUserVO;
    searchCount?: PageUserVO;
    optimizeJoinOfCountSql?: boolean;
    maxLimit?: number;
    countId?: string;
    pages?: number;
  };

  type registerParams = {
    confirmPassword: string;
    userPassword: string;
    userAccount: string;
    email: string;
  };

  type Token = {
    id?: number;
    token?: string;
    revoked?: boolean;
    expired?: boolean;
    userId?: number;
  };

  type User = {
    id?: number;
    userAccount?: string;
    email?: string;
    userPassword?: string;
    userName?: string;
    userAvatar?: string;
    userRole?: 'USER' | 'ADMIN' | 'MANAGER' | 'USERVIP';
    createTime?: string;
    updateTime?: string;
    isPoint?: number;
    isDelete?: number;
    isEnable?: number;
  };

  type UserAddRequest = {
    userName?: string;
    userAccount?: string;
    email?: string;
    password?: string;
    confirmPassword?: string;
    userRole?: string;
  };

  type UserAuthenticationRequest = {
    email?: string;
    password?: string;
  };

  type UserDto = {
    id?: number;
    userAccount?: string;
    email?: string;
    userPassword?: string;
    userName?: string;
    userAvatar?: string;
    userRole?: 'USER' | 'ADMIN' | 'MANAGER' | 'USERVIP';
    createTime?: string;
    updateTime?: string;
    isPoint?: number;
    isDelete?: number;
    isEnable?: number;
  };

  type UserEmailVerificationRequest = {
    email?: string;
    userId?: string;
    code?: string;
  };

  type UserPublishEventRequest = {
    id?: number;
    email?: string;
  };

  type UserQueryRequest = {
    current?: number;
    pageSize?: number;
    sortField?: string;
    sortOrder?: string;
    id?: number;
    unionId?: string;
    mpOpenId?: string;
    userName?: string;
    userProfile?: string;
    userRole?: string;
  };

  type UserUpdateMyRequest = {
    userName?: string;
    userAvatar?: string;
    userProfile?: string;
  };

  type UserUpdateRequest = {
    id?: number;
    userName?: string;
    userAvatar?: string;
    userProfile?: string;
    userRole?: string;
  };

  type UserVO = {
    id?: number;
    userAccount?: string;
    userAvatar?: string;
    userRole?: string;
    createTime?: string;
  };
}
