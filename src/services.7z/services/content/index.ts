// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as aiMasterDataController from './aiMasterDataController';
import * as aiMessageSessionController from './aiMessageSessionController';
import * as aiResultRecordingController from './aiResultRecordingController';
import * as aiRoleController from './aiRoleController';
import * as answerController from './answerController';
import * as questionController from './questionController';
import * as xfMessageController from './xfMessageController';
export default {
  aiRoleController,
  aiMessageSessionController,
  questionController,
  aiResultRecordingController,
  aiMasterDataController,
  answerController,
  xfMessageController,
};
