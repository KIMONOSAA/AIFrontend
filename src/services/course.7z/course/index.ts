// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as courseBaseInfoController from './courseBaseInfoController';
import * as courseLearnRecordController from './courseLearnRecordController';
import * as courseOpenController from './courseOpenController';
import * as coursePublishController from './coursePublishController';
import * as teachplanController from './teachplanController';
export  {
  teachplanController,
  courseBaseInfoController,
  courseLearnRecordController,
  coursePublishController,
  courseOpenController,
};
