// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as bigFileController from './bigFileController';
import * as mediaFilesController from './mediaFilesController';
import * as mediaOpenController from './mediaOpenController';
export {
  bigFileController,
  mediaOpenController,
  mediaFilesController,
};
